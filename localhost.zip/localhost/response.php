<?php      
    $userdata = array(
        "userID" => 0,
        "username" => "empty",
        "email" => "email",
        "avatarBase64" => ""
    );

    $ErrorReq = array(
        "errorMessage" => "empty",
        "isError" => false
    );

    $responseAuthReq = array(
        "type" => "",
        "userdata" => $userdata,
        "error" => $ErrorReq
    );

    $responseResetPasswordReq = array(
        "type" => "",
        "userdata" => $userdata,
        "error" => $ErrorReq
    );
    
    $getResetToken = array(
        "type" => "",
        "resetCode" => "",
        "createdAt" => 0,
        "expiresAt" => 0,
    );

    $responseReq = array(
        "type" => "",
        "userExist" => false
    );

    $responseMoneyReq = array(
        "type" => "",
        "score" => 0,
        "error" => $ErrorReq
    );
?>