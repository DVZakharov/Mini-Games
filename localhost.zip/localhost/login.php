<?php
    require 'sqlConn.php';
    require 'response.php';

    $dt = $_POST;
    $responseAuthReq = ["type" => $dt["type"] ?? ""];

    if (($dt["type"] ?? '') === 'Loginning' && isset($dt["Login"], $dt["Password"])) {
        try {
            $user = GetUserByLogin($dt["Login"]);
            if ($user && isset($user["password"])) {
                if (password_verify(trim($dt["Password"]), $user["password"])) {
                    $responseAuthReq["userdata"] = [
                        "userID"   => $user["userID"],
                        "username" => $user["username"],
                        "email"    => $user["email"],
                        "avatarBase64" => $user["avatarBase64"]
                    ];
                } else {
                    SetError("Неверные логин или пароль");
                }
            } else {
                SetError("Пользователь не найден");
            }
        } catch (PDOException $e) {
            SetError("Ошибка при авторизации: " . $e);
        }
    } else {
        SetError("Неверный или отсутствующий тип запроса");
    }

    function SetError($text) {
        global $responseAuthReq;
        $responseAuthReq["error"] = [
            "errorMessage" => $text,
            "isError"      => true
        ];
    }

    echo json_encode($responseAuthReq, JSON_UNESCAPED_UNICODE);
?>
