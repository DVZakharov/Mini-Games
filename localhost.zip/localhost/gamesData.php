<?php
    require 'sqlConn.php';
    require 'response.php';

    $dt = $_POST;

    function GetGameIDByName($name) {
        global $conn;
        $stmt = $conn->prepare("SELECT gameID FROM dbo.Games WHERE gameName = :gameName");
        $stmt->execute(["gameName" => $name]);        
        $data = $stmt->fetch(PDO::FETCH_ASSOC);
        return $data ? (int)$data["gameID"] : "Игра не найдена";
    }

    function UserExists($userID) {
        global $conn;
        $stmt = $conn->prepare("SELECT userID FROM dbo.Users WHERE userID = :userID");
        $stmt->execute(["userID" => $userID]);
        return $stmt->fetch() !== false;
    }

    function GetScoreRow($gameID, $userID) {
        global $conn;
        $stmt = $conn->prepare("SELECT * FROM dbo.Score WHERE userID = :userID AND gameID = :gameID");
        $stmt->execute(["userID" => $userID, "gameID" => $gameID]);            
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    function GetMapsRow($userID) {
        global $conn;
        $stmt = $conn->prepare("SELECT * FROM dbo.CarParkingShop WHERE userID = :userID");
        $stmt->execute(["userID" => $userID]);            
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    function SetError($text) {
        global $responseMoneyReq;
        $responseMoneyReq["error"]["errorMessage"] = $text;
        $responseMoneyReq["error"]["isError"] = true;
    }

    try {
        if (!isset($dt["type"])) {
            SetError("Не указан параметр type");
        } else {
            $responseMoneyReq["type"] = $dt["type"];

            if ($dt["type"] === 'GetLeaderboard') {
                $stmt = $conn->prepare("
                    SELECT g.gameName, u.username, u.avatarBase64, s.score
                    FROM dbo.Score s
                    JOIN dbo.Users u ON s.userID = u.userID
                    JOIN dbo.Games g ON s.gameID = g.gameID
                    ORDER BY g.gameName, s.score DESC
                ");
                $stmt->execute();
                $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

                $games = [];
                foreach ($results as $row) {
                    $game = $row['gameName'];
                    if (!isset($games[$game])) $games[$game] = [];
                    if (count($games[$game]) < 5) {
                        $games[$game][] = [
                            "rank" => count($games[$game]) + 1,
                            "username" => $row['username'],
                            "score" => (int)$row['score'],
                            "avatar" => $row['avatarBase64']
                        ];
                    }
                }
                $leaderboard = [];
                foreach ($games as $gameName => $entries) {
                    $leaderboard[] = [
                        "gameName" => $gameName,
                        "entries" => $entries
                    ];
                }
                $responseMoneyReq["leaderboard"] = $leaderboard;

            } else if ($dt["type"] === 'GetAccessToMaps' || $dt["type"] === 'BuyMap2'){
                $maps = GetMapsRow($dt["userID"]);
                if ($maps) {
                    if ($dt["type"] === 'GetAccessToMaps') {
                        $responseMoneyReq["type"] = $dt["type"];
                        $responseMoneyReq["map1"] = $maps["map1"]; 
                        $responseMoneyReq["map2"] = $maps["map2"];
                    } else {
                        $stmt = $conn->prepare("UPDATE dbo.CarParkingShop SET map2 = 1 WHERE userID = :userID");
                        $stmt->execute(["userID" => $dt["userID"]]);
                        $maps = GetMapsRow($dt["userID"]);
                        $responseMoneyReq["type"] = $dt["type"];
                        $responseMoneyReq["map1"] = $maps["map1"]; 
                        $responseMoneyReq["map2"] = $maps["map2"];
                    }                    
                } else {
                    $stmt = $conn->prepare("INSERT INTO dbo.CarParkingShop (userID) VALUES (:userID)");
                    $stmt->execute(["userID" => $dt["userID"]]);                    
                    $maps = GetMapsRow($dt["userID"]);
                    if ($dt["type"] === 'GetAccessToMaps') {
                        $responseMoneyReq["type"] = $dt["type"];
                        $responseMoneyReq["map1"] = $maps["map1"]; 
                        $responseMoneyReq["map2"] = $maps["map2"];
                    } else {
                        $stmt = $conn->prepare("UPDATE dbo.CarParkingShop SET map2 = 1 WHERE userID = :userID");
                        $stmt->execute(["userID" => $dt["userID"]]);
                        $maps = GetMapsRow($dt["userID"]);
                        $responseMoneyReq["type"] = $dt["type"];
                        $responseMoneyReq["map1"] = $maps["map1"]; 
                        $responseMoneyReq["map2"] = $maps["map2"];
                    }
                }
            }elseif (isset($dt["game"]) && isset($dt["userID"])) {
                $userID = $dt["userID"];
                $gameName = $dt["game"];
                $gameID = GetGameIDByName($gameName);

                if (!UserExists($userID)) {
                    SetError("Пользователь с ID $userID не найден");
                } elseif (!is_int($gameID)) {
                    SetError($gameID);
                } elseif ($dt["type"] === 'SetScore' || $dt["type"] === 'GetScore') {
                    $existingScore = GetScoreRow($gameID, $userID);
                    $params = ["userID" => $userID, "gameID" => $gameID, "score" => 0];

                    if ($dt["type"] === 'SetScore' && isset($dt["score"])) {
                        $newScore = (int)$dt["score"];
                        $oldScore = isset($existingScore["score"]) ? (int)$existingScore["score"] : 0;
                        $finalScore = max($newScore, $oldScore);
                        $params["score"] = $finalScore;

                        if ($existingScore) {
                            $stmt = $conn->prepare("UPDATE dbo.Score SET score = :score WHERE userID = :userID AND gameID = :gameID");
                        } else {
                            $stmt = $conn->prepare("INSERT INTO dbo.Score (userID, gameID, score) VALUES (:userID, :gameID, :score)");
                        }

                        $stmt->execute($params);
                        $responseMoneyReq["score"] = $finalScore;

                    } elseif ($dt["type"] === 'GetScore') {
                        if ($existingScore) {
                            $responseMoneyReq["score"] = (int)$existingScore["score"];
                        } else {
                            $stmt = $conn->prepare("INSERT INTO dbo.Score (userID, gameID, score) VALUES (:userID, :gameID, :score)");
                            $stmt->execute($params);
                            $responseMoneyReq["score"] = 0;
                        }
                    } else {
                        SetError("Неизвестный тип запроса");
                    }

                } else {
                    SetError("Неподдерживаемый тип запроса: " . $dt["type"]);
                }

            } else {
                SetError("Не указан один из параметров: game или userID");
            }
        }

    } catch (PDOException $e) {
        SetError($e->getMessage());
    }

    echo json_encode($responseMoneyReq, JSON_UNESCAPED_UNICODE);
?>
