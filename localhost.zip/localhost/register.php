<?php
require 'sqlConn.php';
require 'response.php';

$dt = $_POST;
$responseAuthReq = ["type" => $dt["type"] ?? ""];

if (($dt["type"] ?? '') === 'Registration' && isset($dt["UserName"], $dt["Login"], $dt["Password"], $dt["Email"])) {
    try {
        if (GetUserByLogin($dt["Login"])) {
            SetError("Логин уже используется");
        } elseif (GetUserByEmail($dt["Email"])) {
            SetError("Почта уже используется");
        } else {
            $passwordHash = password_hash(trim($dt["Password"]), PASSWORD_BCRYPT);

            if (!empty($dt["Avatar"]) && $dt["Avatar"] !== "no") {
                $stmt = $conn->prepare("
                    INSERT INTO dbo.Users (username, login, password, email, avatarBase64)
                    VALUES (:username, :login, :password, :email, :avatarBase64)
                ");
                $stmt->execute([
                    "username"      => $dt["UserName"],
                    "login"         => $dt["Login"],
                    "password"      => $passwordHash,
                    "email"         => $dt["Email"],
                    "avatarBase64"  => $dt["Avatar"]
                ]);
            } else {
                $stmt = $conn->prepare("
                    INSERT INTO dbo.Users (username, login, password, email)
                    VALUES (:username, :login, :password, :email)
                ");
                $stmt->execute([
                    "username" => $dt["UserName"],
                    "login"    => $dt["Login"],
                    "password" => $passwordHash,
                    "email"    => $dt["Email"]
                ]);                
            }
            $user = GetUserByLogin($dt["Login"]);
            $responseAuthReq["userdata"] = [
                "userID"   => $user["userID"],
                "username" => $user["username"],
                "email"    => $user["email"],
                "avatar" => $user["avatarBase64"]
            ];
        }
    } catch (PDOException $e) {
        SetError("Ошибка базы данных: " . $e->getMessage());
    }
} else {
    SetError("Неверный или неполный запрос на регистрацию");
}

function SetError($text) {
    global $responseAuthReq;
    $responseAuthReq["error"] = [
        "errorMessage" => $text,
        "isError"      => true
    ];
}

echo json_encode($responseAuthReq, JSON_UNESCAPED_UNICODE);
?>
