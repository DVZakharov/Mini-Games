<?php 
    require 'sqlConn.php';
    require 'response.php';
    
    $dt = $_POST;

    if (isset($dt["type"])) {
        if ($dt["type"] == 'existUsersByEmail' && isset($dt["Email"])) {
            $responseReq["type"] = $dt["type"];
            try {
                if (GetUserByEmail($dt["Email"])) {
                    $responseReq["userExist"] = true;
                } else {
                    $responseReq["userExist"] = false;
                }
            } catch (PDOExeption $e) {}            
        } 
    } 
    echo json_encode($responseReq, JSON_UNESCAPED_UNICODE);
?>