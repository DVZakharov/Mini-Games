<?php
    $serverName = "tcp:user";
    $database = "Mini-Games_Collection";
    $login = "App";
    $pass = "-dzTisA6";
    
    try {
        $conn = new PDO("sqlsrv:Server=$serverName; Database=$database", $login, $pass);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);            
    } catch (PDOExeption $e) {
        die("Ошибка подключения к базе данных: ".$e->getMessage());
    }

    function GetUserByLogin($login) {
        global $conn;
        $stmt = $conn->prepare("SELECT * FROM dbo.Users WHERE login = :login");
        $stmt->execute(['login' => $login]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    function GetUserByEmail($email) {
        global $conn;
        $stmt = $conn->prepare("SELECT * FROM dbo.Users WHERE email = :email");
        $stmt->execute(['email' => $email]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }     
?>