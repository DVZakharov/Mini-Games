<?php
    require 'sqlConn.php';
    require 'response.php';

    $dt = $_POST;

    // === Генерация цифрового токена ===
    function generateNumericToken($length = 6) {
        return str_pad(random_int(0, pow(10, $length) - 1), $length, '0', STR_PAD_LEFT);
    }

    // === Обработка типов запросов ===
    if (($dt["type"] ?? '') === 'getResetToken' && isset($dt["Email"])) {
        $getResetToken["type"] = $dt["type"];
        try {
            $email = trim($dt["Email"]);
            $user = GetUserByEmail($email);

            if ($user) {
                $code = generateNumericToken();
                $createdAt = time();
                $expiresAt = $createdAt + 120;

                $getResetToken["resetCode"] = $code;
                $getResetToken["createdAt"] = $createdAt;
                $getResetToken["expiresAt"] = $expiresAt;
            }

        } catch (PDOException $e) {
            logError("Ошибка при генерации токена: " . $e->getMessage());
        }
        echo json_encode($getResetToken, JSON_UNESCAPED_UNICODE);
    }
    elseif (($dt["type"] ?? '') === 'resetPassword'
        && isset($dt["Email"], $dt["Code"], $dt["NewPassword"], $dt["OriginalCode"], $dt["ExpiresAt"])) {
        $responseAuthReq["type"] = $dt["type"];
        try {
            if (time() > (int)$dt["ExpiresAt"]) {
                setError("Код сброса истёк. Запросите новый.");
            }
            elseif ($dt["Code"] !== $dt["OriginalCode"]) {
                setError("Неверный код подтверждения.");
            } else {
                $user = GetUserByEmail($dt["Email"]);
                if ($user) {
                    $stmt = $conn->prepare("UPDATE dbo.Users SET password = :password WHERE email = :email");
                    $stmt->execute([
                        "password" => password_hash($dt["NewPassword"], PASSWORD_BCRYPT),
                        "email" => $dt["Email"]
                    ]);
                    $responseAuthReq["userdata"] = [
                        "userID" => $user["userID"],
                        "username" => $user["username"],
                        "email" => $user["email"],
                        "avatar" => $user["avatarBase64"]
                    ];

                } else {
                    setError("Пользователь не найден.");
                }
            }            
        } catch (Exception $e) {
            setError("Ошибка сброса пароля: " . $e->getMessage());
        }
        echo json_encode($responseAuthReq, JSON_UNESCAPED_UNICODE);
    } else {
        setError("Неверный или неполный запрос.");
        echo json_encode($responseAuthReq, JSON_UNESCAPED_UNICODE);
    }

    // === Вспомогательные функции ===
    function setError($message) {
        global $responseAuthReq;
        $responseAuthReq["error"] = [
            "isError" => true,
            "errorMessage" => $message
        ];
    }

    function logError($msg) {
        error_log("[Reset Error] " . $msg);
    }    
?>