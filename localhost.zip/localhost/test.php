<?php 
    require 'sqlConn.php';
    require 'response.php';

    $login = "zxcvb";

    print_r(gettype(base64_encode(GetUserByLogin($login)["avatarBinary"])));
?>